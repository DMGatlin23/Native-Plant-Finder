/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package plantserver;

/**
 *
 * @author anastasiarivera
 */
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class PlantServer {
    public static void main(String[] args) {
        final int PORT = 8080;
        try {
            ServerSocket serverSocket = new ServerSocket(PORT);
            System.out.println("Server started on port " + PORT);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                // Handle client connection
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
