/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.plantapp;
import java.io.*;
import java.net.*;
/**
*
* @author abena
*/
public class Plantapp {
public static void main(String[] args) {
// TODO code application logic here
System.out.println("Initiating Client...");
String hostName = "localhost";//"127.0.0.1";
int portNumber = 8082;//must match the server's port number. use a number
//greater than 1023
System.out.println("Creating a client socket to connect on port " +
portNumber + " to host " + hostName);
try {
Socket aSocket = new Socket(hostName, portNumber);
PrintWriter out = new PrintWriter(aSocket.getOutputStream(), true);
BufferedReader in = new BufferedReader(new
InputStreamReader(aSocket.getInputStream()));
System.out.println("Write a message below for the server: ");
BufferedReader stdIn = new BufferedReader(new
InputStreamReader(System.in));
String userInput = stdIn.readLine();
out.println(userInput);//sending message to server
System.out.println("Server's Message: " + in.readLine());
System.out.println("Server's Message: " + in.readLine());
System.out.println("Server's Message: " + in.readLine());
out.close();
aSocket.close();
} catch (UnknownHostException e) {
System.err.println("Can't Find Host " + hostName);
System.exit(1);
} catch (IOException e) {
System.err.println("Couldn't get I/O for the connection to "
+ hostName);
System.out.println(e);
}
}
}







