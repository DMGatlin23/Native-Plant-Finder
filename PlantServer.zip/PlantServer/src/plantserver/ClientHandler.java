package plantserver;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author anastasiarivera
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClientHandler implements Runnable {
    private Socket clientSocket;
    private DBHandler dbHandler;

    public ClientHandler(Socket clientSocket, DBHandler dbHandler) {
        this.clientSocket = clientSocket;
        this.dbHandler = dbHandler;
    }

    @Override
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            // Read client request
            String request = in.readLine();
            // Process request and retrieve data from database
            ResultSet resultSet = dbHandler.executeQuery("SELECT * FROM plants WHERE ...");

            // Send response back to client
            while (resultSet.next()) {
                out.println(resultSet.getString("plant_name"));
                // Send other plant details as needed
            }

            // Close resources
            in.close();
            out.close();
            clientSocket.close();
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }
}



